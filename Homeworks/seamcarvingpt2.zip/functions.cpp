#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include "functions.h"

using namespace std;

/* seamcarving functions */

Pixel** createImage(int width, int height) {
  cout << "Start createImage... " << endl;
  
  Pixel** image = new Pixel*[width];
  
  bool fail = false;
  
  for (int i=0; i < width; ++i) {  // loop through every column
    image[i] = new Pixel[height];  // assign every col
    
    if (image[i] == nullptr) {  // if not allocated
      fail = true;
    }
  }
  
  if (fail) {
    for (int i=0; i < width; ++i) {
      delete [] image[i];  // deleting null pt
    }
    delete [] image;  // delete arr of ptr
    return nullptr;
  }
  
  for (int row=0; row<height; ++row) {
    for (int col=0; col<width; ++col) {
      image[col][row] = { 0, 0, 0 };
    }
  }
  cout << "End createImage... " << endl;
  return image;
}

void deleteImage(Pixel** image, int width) {  // delete image function  
    cout << "Start deleteImage..." << endl;
    // avoid memory leak
    for (int i=0; i<width; ++i) {
        delete [] image[i];
    }
    delete [] image;
    image = nullptr;
}

int* createSeam(int length) { 
  if(length == 0)
    return nullptr;
  int* seam = new int[length];
  for (int i = 0; i < length; i++){
    seam[i] = 0;
  }
  return seam;
}

void deleteSeam(int* seam) {
  delete[] seam;
}

int inRangePixel(Pixel p){  // used in outputImage Pixel .(red/green/blue) values
  if(p.r > 255 || p.r < 0)
    return p.r;
  if(p.g > 255 || p.g < 0)
    return p.g;
  if(p.b > 255 || p.b < 0)
    return p.b;
  return 0;
}

bool loadImage(string filename, Pixel** image, int width, int height) {
   cout << "Loading image..." << endl;

  int cValsNum = -1;
  int calcColorVals = height*width*3;

  ifstream ifs (filename);  // input file stream
  if (!ifs.is_open()) {
    cout << "Error: failed to open input file - " << filename << endl;  // check if opened
    return false;
  }

  char tpixel_ye1[3];
  ifs >> tpixel_ye1; // p3

  int wdt_2 = 0, ht_2 = 0; // width height
  ifs >> wdt_2;
  if (ifs.fail()){  // input validation
    cout << "Error: read non-integer value" << endl;
    return 0;
  }
  if (wdt_2 != width) {
    cout << "Error: input width (" << width << ") does not match value in file (" << wdt_2 << ")" << endl;  // widths need to match
    return false;
  }
  ifs >> ht_2;
  if (ifs.fail()){
    cout << "Error: read non-integer value" << endl;
    return 0;
  }
  if (ht_2 != height) {
    cout << "Error: input height (" << height << ") does not match value in file (" << ht_2 << ")" << endl;  // heights need to match
    return false;
  }

  int maxColor1 = 0;
  ifs >> maxColor1;
  char tempNum[3];
  while(ifs.eof() == false){
    ifs >> tempNum;
    if(tempNum[0] != '\n')
      cValsNum++;
  }

  ifs.close();
  ifs.clear();

  if(cValsNum < calcColorVals){
    cout << "Error: not enough color values" << endl;
    return false;
  }

  if(cValsNum > calcColorVals){
    cout << "Error: too many color values" << endl;
    return false;
  }

  ifs.open(filename);
  if (!ifs.is_open()) {  // ifstream opened
    cout << "Error: failed to open input file - " << filename << endl;
    return false;
  }
  
  char tpixel_ye[3];
  ifs >> tpixel_ye;
  if ((toupper(tpixel_ye[0]) != 'P') || (tpixel_ye[1] != '3')) { // correct tpixel_ye
    cout << "Error: type is " << tpixel_ye << " instead of P3" << endl;
    return false;
  }
  
  int w = 0, h = 0;
  ifs >> w >> h;
  if (w != width) {
    cout << "Error: input width (" << width << ") does not match value in file (" << w << ")" << endl;
    return false;
  }
  if (h != height) {
    cout << "Error: input height (" << height << ") does not match value in file (" << h << ")" << endl;
    return false;
  }
  
  // max
  int maxCol1 = 0;
  ifs >> maxCol1;
  if (maxCol1 != 255) {
    cout << "Error: file is not using RGB color values." << endl;
    return false;
  }
  
  // rgb vals
  for(int ht_1 = 0; ht_1 < height; ht_1++){
    for(int wdt_1 = 0; wdt_1 < width; wdt_1++){
      if(ifs.eof()){
        cout << "Error: not enough color values" << endl;
        return false;
      }
      ifs >> image[wdt_1][ht_1].r;
      if(ifs.eof()) {
        cout << "Error: not enough color values" << endl;
        return false;
      }
      else if(ifs.fail()){
        cout << "Error: read non-integer value" << endl;
        return false;
      }
      ifs >> image[wdt_1][ht_1].g;
      if(ifs.fail()){
        cout << "Error: read non-integer value" << endl;
        return false;
      }
      ifs >> image[wdt_1][ht_1].b;
      if(ifs.eof()) {
        cout << "Error: not enough color values" << endl;
        return false;
      }
      else if(ifs.fail()){
        cout << "Error: read non-integer value" << endl;
        return false;
      }
      else if (inRangePixel(image[wdt_1][ht_1]) != 0){
        cout << "Error: invalid color value " << inRangePixel(image[wdt_1][ht_1]) << endl;
        return false;
      }
    }
  }
  ifs.close(); // close
  ifs.clear();
  return true;
}

bool outputImage(string filename, Pixel** image, int width, int height) {
  cout << "Outputting image..." << endl;
  ofstream ofs (filename);
  
  if(!ofs){
    cout << "Error: failed to open output file " << filename << endl;
    return false;
  }
  else {
    ofs << "P3" << endl;  // output p3
    ofs << width << " " << height << endl;
    ofs << 255 << endl;  // max color val
    for(int ht_1 = 0; ht_1 < height; ht_1++){ 
      for(int wdt_1 = 0; wdt_1 < width; wdt_1++){
        if(wdt_1!=width-1)
          ofs << image[wdt_1][ht_1].r << " " << image[wdt_1][ht_1].g << " " << image[wdt_1][ht_1].b << " ";  // pixel vals
        else
          ofs << image[wdt_1][ht_1].r << " " << image[wdt_1][ht_1].g << " " << image[wdt_1][ht_1].b;  // pixel vals
      }
      ofs << endl;
    }
  }

  ofs.close();
  return true;
}

int energy(Pixel** image, int x, int y, int width, int height) { 
  int dxr, dxg, dxb;
    if(x > 0 && x < width - 1){
        dxr = abs(image[x-1][y].r - image[x+1][y].r);

        dxg = abs(image[x-1][y].g - image[x+1][y].g);

        dxb = abs(image[x-1][y].b - image[x+1][y].b);
    } else if(x == 0){

        dxr = abs(image[width-1][y].r - image[x+1][y].r);

        dxg = abs(image[width-1][y].g - image[x+1][y].g);

        dxb = abs(image[width-1][y].b - image[x+1][y].b);
    } else{

        dxr = abs(image[x-1][y].r - image[0][y].r);

        dxg = abs(image[x-1][y].g - image[0][y].g);

        dxb = abs(image[x-1][y].b - image[0][y].b);
    }

    int dyr, dyg, dyb;
    if(y > 0 && y < height - 1) {
        dyr = abs(image[x][y-1].r - image[x][y+1].r);

        dyg = abs(image[x][y-1].g - image[x][y+1].g);

        dyb = abs(image[x][y-1].b - image[x][y+1].b);

    } else if( y == 0){
        dyr = abs(image[x][height-1].r - image[x][y+1].r);

        dyg = abs(image[x][height-1].g - image[x][y+1].g);

        dyb = abs(image[x][height-1].b - image[x][y+1].b);

    } else{

        dyr = abs(image[x][y-1].r - image[x][0].r);

        dyg = abs(image[x][y-1].g - image[x][0].g);

        dyb = abs(image[x][y-1].b - image[x][0].b);
    }

    int gx, gy;

    gx = dxr*dxr + dxg*dxg + dxb*dxb;

    gy = dyr*dyr + dyg*dyg + dyb*dyb;

    int tot_e = gx + gy;

    return tot_e;  // tot energy
}


int loadVerticalSeam(Pixel** image, int start_col, int width, int height, int* seam) {

    int down, left, right, col, energy_tot;
                                                // (255^2)*6 = 390150 (maximum energy)
    const int ENERGY_MAX = 390151;
 
    col = start_col;
    energy_tot = energy(image, col, 0, width, height);
    seam[0] = col;
    for(int r = 1; r < height; r++){

        left = (col > 0) ? energy(image, col-1, r, width, height) : ENERGY_MAX;
        down = energy(image, col, r, width, height);

        right = (col < height-1) ? energy(image, col+1, r, width, height) : ENERGY_MAX;
        if(left < down && left < right){

            col--;
            energy_tot += left;
        } else if(right < down){

            col++;
            energy_tot += right;
        } else{
            energy_tot += down;
        }
  
        seam[r] = col;
    }
    return energy_tot;


}

int* findMinVerticalSeam(Pixel** image, int width, int height) {

    int energy_min, vertical_current;
    int* vert_seam = new int[height];
    int* minSeam = new int[height];
 
    energy_min = loadVerticalSeam(image, 0, width, height, minSeam);
    for(int i = 1; i < width; i++){

        vertical_current = loadVerticalSeam(image, i, width, height, vert_seam);
        
        if(vertical_current < energy_min){

            energy_min = vertical_current;
            for(int r = 0; r < height; r++){
                minSeam[r] = vert_seam[r];
            }
        }
    }
    delete[] vert_seam;
    return minSeam;
  
}

void removeVerticalSeam(Pixel** image, int width, int height, int* verticalSeam) {
  // image[width-2][height-2].r = verticalSeam[0];

  /*  for (int i = 0; i < height; i++) {  // loop through and delete

    for (int j = verticalSeam[i]; j < width - 1; i++) { // loop through which pixels should be removed

      image[j][i] = image[j+1][i];

    }
  }*/

  int col;
  Pixel temp{};
  for(int i  = 0; i < height; i++){
    col = verticalSeam[i];
    temp = image[col][i];
    for(int v = col; v < width-1; v++){
      image[v][i] = image[v + 1][i];
    }
      image[width-1][i] = temp;
    }
}


int loadHorizontalSeam(Pixel** image, int start_row, int width, int height, int* seam) {
    int up, down, right, row, energy_tot;

    const int ENERGY_MAX = 390151;

    row = start_row;
    energy_tot = energy(image, 0, row, width, height); // starting
    seam[0] = row;
    for(int i = 1; i < width; i++){

        up = (row > 0) ? energy(image, i, row-1, width, height) : ENERGY_MAX;

        right = energy(image, i, row, width, height);

        down = (row < height-1) ? energy(image, i, row+1, width, height) : ENERGY_MAX;

        if(down < right && down < up){
            row++;
            energy_tot += down;
        } else if(up < right){
            row--;
            energy_tot += up;  // row up
        } else{
            energy_tot += right;  // same
        }
     
        seam[i] = row;  // value to seam array
    }
    return energy_tot;
}

int* findMinHorizontalSeam(Pixel** image, int width, int height) {

int* minHorSeam = createSeam(width);
  int* hor_seam = createSeam(width);
  int hseam_e = loadHorizontalSeam(image, 0, width, height, hor_seam);
  
  int eh_loop = 0;
  for (int i = 0; i < width; i++) {
        minHorSeam[i] = hor_seam[i];
  }

  for (int j = 1; j < height; j++) {
    
    eh_loop = loadHorizontalSeam(image, j, width, height, hor_seam);

    if (eh_loop < hseam_e) {
      
      hseam_e = eh_loop;
      for (int i = 0; i < width; i++) {
        minHorSeam[i] = hor_seam[i];
      }
    }
  }

  deleteSeam(hor_seam);
  return minHorSeam;
}

void removeHorizontalSeam(Pixel** image, int width, int height, int* horizontalSeam) {
 // image[width-2][height-2].r = horizontalSeam[0];

    int row;
    Pixel temp{};
    for(int c = 0; c < width; c++) {
        row = horizontalSeam[c];
        temp = image[c][row];
        for (int r = row; r < height-1; r++) {
            image[c][r] = image[c][r + 1];
        }
        image[c][height-1] = temp;
    }
}