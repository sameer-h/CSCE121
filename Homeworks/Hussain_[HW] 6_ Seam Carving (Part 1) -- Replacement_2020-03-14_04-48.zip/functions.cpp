#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include "functions.h"

using namespace std;

/* seamcarving functions */

Pixel** createImage(int width, int height) {
  cout << "Start createImage... " << endl;
  
  Pixel** image = new Pixel*[width];
  
  bool fail = false;
  
  for (int i=0; i < width; ++i) {  // loop through every column
    image[i] = new Pixel[height];  // assign every col
    
    if (image[i] == nullptr) {  // if not allocated
      fail = true;
    }
  }
  
  if (fail) {
    for (int i=0; i < width; ++i) {
      delete [] image[i];  // deleting null pt
    }
    delete [] image;  // delete arr of ptr
    return nullptr;
  }
  
  for (int row=0; row<height; ++row) {
    for (int col=0; col<width; ++col) {
      image[col][row] = { 0, 0, 0 };
    }
  }
  cout << "End createImage... " << endl;
  return image;
}

void deleteImage(Pixel** image, int width) {  // delete image function
  cout << "Start deleteImage..." << endl;

  for (int i=0; i<width; ++i) {
    delete [] image[i];  // deleting every array
  }
  delete [] image;
  image = nullptr;
}

int* createSeam(int length) { 
  if(length == 0)
    return nullptr;
  int* seam = new int[length];
  for (int i = 0; i < length; i++){
    seam[i] = 0;
  }
  return seam;
}

void deleteSeam(int* seam) {
  delete seam;
}

bool loadImage(string filename, Pixel** image, int width, int height) {
   cout << "Loading image..." << endl;

  int cValsNum = -1;
  int calcColorVals = height*width*3;

  ifstream ifs (filename);  // input file stream
  if (!ifs.is_open()) {
    cout << "Error: failed to open input file - " << filename << endl;  // check if opened
    return false;
  }

  char tpixel_ye1[3];
  ifs >> tpixel_ye1; // p3

  int wdt_2 = 0, ht_2 = 0; // width height
  ifs >> wdt_2;
  if (ifs.fail()){  // input validation
    cout << "Error: read non-integer value" << endl;
    return 0;
  }
  if (wdt_2 != width) {
    cout << "Error: input width (" << width << ") does not match value in file (" << wdt_2 << ")" << endl;  // widths need to match
    return false;
  }
  ifs >> ht_2;
  if (ifs.fail()){
    cout << "Error: read non-integer value" << endl;
    return 0;
  }
  if (ht_2 != height) {
    cout << "Error: input height (" << height << ") does not match value in file (" << ht_2 << ")" << endl;  // heights need to match
    return false;
  }

  int maxColor1 = 0;
  ifs >> maxColor1;
  char tempNum[3];
  while(ifs.eof() == false){
    ifs >> tempNum;
    if(tempNum[0] != '\n')
      cValsNum++;
  }

  ifs.close();
  ifs.clear();

  if(cValsNum < calcColorVals){
    cout << "Error: not enough color valuesssssssss" << endl;
    return false;
  }

  if(cValsNum > calcColorVals){
    cout << "Error: too many color values" << endl;
    return false;
  }

  ifs.open(filename);
  if (!ifs.is_open()) {  // ifstream opened
    cout << "Error: failed to open input file - " << filename << endl;
    return false;
  }
  
  char tpixel_ye[3];
  ifs >> tpixel_ye;
  if ((toupper(tpixel_ye[0]) != 'P') || (tpixel_ye[1] != '3')) { // correct tpixel_ye
    cout << "Error: type is " << tpixel_ye << " instead of P3" << endl;
    return false;
  }
  
  int w = 0, h = 0;
  ifs >> w >> h;
  if (w != width) {
    cout << "Error: input width (" << width << ") does not match value in file (" << w << ")" << endl;
    return false;
  }
  if (h != height) {
    cout << "Error: input height (" << height << ") does not match value in file (" << h << ")" << endl;
    return false;
  }
  
  // max
  int maxCol1 = 0;
  ifs >> maxCol1;
  if (maxCol1 != 255) {
    cout << "Error: file is not using RGB color values." << endl;
    return false;
  }
  
  // rgb vals
  for(int ht_1 = 0; ht_1 < height; ht_1++){
    for(int wdt_1 = 0; wdt_1 < width; wdt_1++){
      if(ifs.eof()){
        cout << "Error: not enough color values" << endl;
        return false;
      }
      ifs >> image[wdt_1][ht_1].r;
      if(ifs.eof()) {
        cout << "Error: not enough color values" << endl;
        return false;
      }
      else if(ifs.fail()){
        cout << "Error: read non-integer value" << endl;
        return false;
      }
      ifs >> image[wdt_1][ht_1].g;
      if(ifs.fail()){
        cout << "Error: read non-integer value" << endl;
        return false;
      }
      ifs >> image[wdt_1][ht_1].b;
      if(ifs.eof()) {
        cout << "Error: not enough color values" << endl;
        return false;
      }
      else if(ifs.fail()){
        cout << "Error: read non-integer value" << endl;
        return false;
      }
      else if (inRangePixel(image[wdt_1][ht_1]) != 0){
        cout << "Error: invalid color value " << inRangePixel(image[wdt_1][ht_1]) << endl;
        return false;
      }
    }
  }
  ifs.close(); // close
  ifs.clear();
  return true;
}

bool outputImage(string filename, Pixel** image, int width, int height) {
  cout << "Outputting image..." << endl;
  ofstream ofs (filename);
  
  if(!ofs){
    cout << "Error: failed to open output file " << filename << endl;
    return false;
  }
  else {
    ofs << "P3" << endl;  // output p3
    ofs << width << " " << height << endl;
    ofs << 255 << endl;  // max color val
    for(int ht_1 = 0; ht_1 < height; ht_1++){ 
      for(int wdt_1 = 0; wdt_1 < width; wdt_1++){
        if(wdt_1!=width-1)
          ofs << image[wdt_1][ht_1].r << " " << image[wdt_1][ht_1].g << " " << image[wdt_1][ht_1].b << " ";  // pixel vals
        else
          ofs << image[wdt_1][ht_1].r << " " << image[wdt_1][ht_1].g << " " << image[wdt_1][ht_1].b;  // pixel vals
      }
      ofs << endl;
    }
  }

  ofs.close();
  return true;
}

int energy(Pixel** image, int x, int y, int width, int height) { 
  int en_x = x-1;
  int pixel_x = x+1;
  int en_y = y-1;
  int pixel_y = y+1;

  // using dual energy gradient function

  // Δx2(x, y) = Rx(x, y)2 + Gx(x, y)2 + Bx(x, y)2

  

  if (x == 0)
    en_x = width-1;
  if (x == width-1)
    pixel_x = 0;
  if (y == 0)
    en_y = height-1;
  if (y == height-1)
    pixel_y = 0;
    

  //  Rx(x, y), Gx(x, y), and Bx(x, y) are the absolute value in differences of red, green, and blue components

  //  between pixel (x + 1, y) and pixel (x − 1, y). 

  int rx = abs(image[pixel_x][y].r - image[en_x][y].r); 

  int gx = abs(image[pixel_x][y].g - image[en_x][y].g);

 // the square of the y-gradient Δy2(x, y)

  int bx = abs(image[pixel_x][y].b - image[en_x][y].b);

  int ry = abs(image[x][pixel_y].r - image[x][en_y].r);

  int gy = abs(image[x][pixel_y].g - image[x][en_y].g);

  int by = abs(image[x][pixel_y].b - image[x][en_y].b);

  int gra_x = pow(rx, 2) + pow(gx, 2) + pow(bx, 2); // following formula
  int gra_y = pow(ry, 2) + pow(gy, 2) + pow(by, 2);
  int energyTotal = gra_x + gra_y;
  return energyTotal;
}

int inRangePixel(Pixel p){  // used in outputImage Pixel .(red/green/blue) values
  if(p.r > 255 || p.r < 0)
    return p.r;
  if(p.g > 255 || p.g < 0)
    return p.g;
  if(p.b > 255 || p.b < 0)
    return p.b;
  return 0;
}
